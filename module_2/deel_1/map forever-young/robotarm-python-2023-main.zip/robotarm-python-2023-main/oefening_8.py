from RobotArm import RobotArm

robotArm = RobotArm('exercise 8')

# Jouw python instructies zet je vanaf hier:

robotArm.moveRight()
X=0
while X<7:
    robotArm.grab()
    for a in range(0,8):
        robotArm.moveRight()
    robotArm.drop()
    for i in range(0,8):
        robotArm.moveLeft()
    X+=1
# Na jouw code wachten tot het sluiten van de window:
robotArm.wait()